/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author Charly Ponce
 */
public enum Tokens {
NombreP,
codigoP,
articulo,
separador2,
parA,
numero2,
PuntoyComa,
parC,
precio,
FIN_FORMULARIO,
Error
}
